<?php
    //Podaci za spajanje na bazz
    $server = "localhost";
    $user = "WebDiP2021x008";
    $pass = "admin_R3Xz";
    $dataBase = "WebDiP2021x008";
    $charset = "utf8";

    //Podaci za aktiviranje računa
    $vrijemeZaAktivacijuUSatima = 7;

    //Podaci za login
    $brojPrijavaZaZakljucavanje = 3;
?>