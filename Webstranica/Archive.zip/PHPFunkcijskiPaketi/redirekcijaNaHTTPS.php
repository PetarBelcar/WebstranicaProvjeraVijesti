<?php
    if(!isset($_SERVER['HTTPS']))
    {
        header("Location: https://". $_SERVER["HTTP_HOST"] . $_SERVER['REQUEST_URI']);
        exit;
    }
    else if($_SERVER['HTTPS'] != "on")
    {
        header("Location: https://". $_SERVER["HTTP_HOST"] . $_SERVER['REQUEST_URI']);
        exit;
    }
?>